import React from 'react';
import './style.css';
import { Table } from 'react-bootstrap';
import ButtonDemo from './ButtonDemo';

export default function App() {
  return (
    <div>
      <ButtonDemo />
    </div>
  );
}
