import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap-css-only';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

class FlightSearch extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      firstname: '',
      lastname: '',
      passengers: '',
      errors: [],
      startDate: new Date(),
    };

    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(date) {
    this.setState({
      startDate: date,
    });
  }

  hasError(key) {
    return this.state.errors.indexOf(key) !== -1;
  }

  handleInputChange(event) {
    var key = event.target.name;
    var value = event.target.value;
    var obj = {};
    obj[key] = value;
    this.setState(obj);
  }

  handleSubmit(event) {
    event.preventDefault();
    //VALIDATE
    var errors = [];

    //firstname
    if (this.state.firstname === '') {
      errors.push('firstname');
    }

    //lastname
    if (this.state.lastname === '') {
      errors.push('lastname');
    }

    //lastname
    if (this.state.passengers === '') {
      errors.push('passengers');
    }

    this.setState({
      errors: errors,
    });

    if (errors.length > 0) {
      return false;
    } else {
      alert('everything good. submit form!');
    }
  }

  render() {
    return (
      <form className="row form-control">
        <div className="col-lg-3">
          <label htmlFor="firstname">From</label>
          <input
            autoComplete="off"
            className={
              this.hasError('firstname')
                ? 'form-control is-invalid'
                : 'form-control'
            }
            name="firstname"
            value={this.state.firstname}
            onChange={this.handleInputChange}
          />
          <div
            className={
              this.hasError('firstname') ? 'inline-errormsg' : 'hidden'
            }
          >
            Please enter From City
          </div>
        </div>

        <div className="col-lg-3">
          <label htmlFor="lastname">To</label>
          <input
            autoComplete="off"
            className={
              this.hasError('lastname')
                ? 'form-control is-invalid'
                : 'form-control'
            }
            name="lastname"
            value={this.state.lastname}
            onChange={this.handleInputChange}
          />
          <div
            className={this.hasError('lastname') ? 'inline-errormsg' : 'hidden'}
          >
            Please enter To City
          </div>
        </div>

        <div className="col-lg-3">
          <label htmlFor="Total Passengers">Passengers | Class</label>
          <input
            autoComplete="off"
            className={'form-control'}
            name="passengers"
            value={this.state.passengers}
            onChange={this.handleInputChange}
            placeholder="1 Traveller, Economy"
          />
          <div
            className={
              this.hasError('passengers') ? 'inline-errormsg' : 'hidden'
            }
          >
            Total Travellers
          </div>
        </div>

        <div className="col-lg-3">
          <label htmlFor="Departue Time">Depart </label>
          <DatePicker
            selected={this.state.startDate}
            onChange={this.handleChange}
            name="startDate"
            dateFormat="d MMM Y"
            className={
              this.hasError('passengers')
                ? 'form-control is-invalid'
                : 'form-control'
            }
          />
          <div
            className={
              this.hasError('passengers') ? 'inline-errormsg' : 'hidden'
            }
          >
            Total Travellers
          </div>
        </div>

        <div className="col-lg-3">
          <p></p>
          <button className="btn btn-success" onClick={this.handleSubmit}>
            Happy Easy Search
          </button>
        </div>
      </form>
    );
  }
}

export default FlightSearch;
