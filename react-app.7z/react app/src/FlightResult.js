import React from 'react';
import fdata from './flight_result';
import cdata from './city';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Table from 'react-bootstrap/Table ';
import { Button } from 'react-bootstrap';

const FlightResult = () => {
  const [flightsData] = React.useState(fdata);
  const [cityData] = React.useState(cdata);

  return (
    <div style={{ display: 'flex', alignItems: 'top' }}>
      <div className="container">
        <h4>
          <u>Flights Data</u>
        </h4>
        <Table striped bordered hover>
          <tbody>
            <tr>
              <th>Flight Name</th>
              <th>Flight NUmber</th>
              <th>Duration</th>
              <th>Price</th>
              <th>Stops</th>
            </tr>
            {flightsData &&
              flightsData.map((v, i) => (
                <tr>
                  <td>
                    <img src={v.logo} width="50" height="25" />
                    {v.airline_name}
                  </td>
                  <td>{v.flight_number}</td>
                  <td>{v.duration}</td>
                  <td>₹{v.price}</td>
                  <td>{v.noofstops}</td>
                  <td>
                    {' '}
                    <Button variant="info">Book NOW</Button>
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
      </div>
    </div>
  );
};

export default FlightResult;
