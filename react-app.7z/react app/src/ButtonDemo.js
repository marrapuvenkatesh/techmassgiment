import React from 'react';
import { Button } from 'react-bootstrap';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import FlightSearch from './FlightSearch';
import FlightResult from './FlightResult';

class ButtonDemo extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.handleSearch = this.handleSearch.bind(this);
    this.handleResult = this.handleResult.bind(this);
    this.state = {
      showForm: false,
      showResult: false,
    };
  }
  handleSearch() {
    this.setState({ showForm: true, showResult: false });
  }

  handleResult() {
    this.setState({ showResult: true, showForm: false });
  }

  render() {
    return (
      <div>
        <h4 className="text-center">Agent Applicaiton For Flight Booking</h4>
        <Container className="text-center">
          <Row>
            <Col>
              <Button bsStyle="primary" onClick={this.handleSearch}>
                Search Flight
              </Button>{' '}
              <Button bsStyle="primary" onClick={this.handleResult}>
                Flight Search Result{' '}
              </Button>
            </Col>
          </Row>
        </Container>
        {this.state.showForm ? <FlightSearch /> : null}
        {this.state.showResult ? <FlightResult /> : null}
      </div>
    );
  }
}
export default ButtonDemo;
